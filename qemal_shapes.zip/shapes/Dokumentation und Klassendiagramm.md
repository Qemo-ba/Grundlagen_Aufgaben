# Dokumentation und Klassendiagramm

[Klassendiagramm](https://ims-module1.gitlab.io/Qemals_Dokumentationen/Klassendiagramm%20Aufgabe%207/)

[Dokumentation](https://ims-module1.gitlab.io/Qemals_Dokumentationen/shapes_documentation/)
